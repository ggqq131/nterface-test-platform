var pageUrl = "/message/page.html";
var deleteUrl = "/message/delete.html";
var updateUrl = "/message/update-custom.html";

$(function(){
	queryFY();
});

/**
 * 填充表格数据
 * @param pageInfo  ajax返回的参数信息
 */
function showTable(pageInfo) {
    var total = pageInfo.totalElements;//总数
    var pageNum = parseFloat(pageInfo.number)+1;//页号
    var pageSize = pageInfo.size;//页大小

    var beans = pageInfo.content;
    $("#tbody").html("");//清空表格中数据并重新填充数据
    for(var i=0,length_1 = beans.length;i<length_1;i++){
        var html = "<div onclick='showDetailWindow(" + beans[i].id + ")'>" + beans[i].name + "(" + beans[i].createtimeStr + ")</div><hr class=\"layui-border-green\">";
        $("#tbody").append(html);
    }

    //开启分页组件
    showPage(total, pageNum, pageSize);
}

function showDetailWindow(id) {
    window.open("/message/detail/" + id);
}