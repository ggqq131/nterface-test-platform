function doCount() {
    var countModel = $("#countModel").val();
    $.get('/task/do-count.html?countModel=' + countModel, function (res) {
        $("#prompt").text(res.data.prompt);

        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('main'));
        var datas = res.data.datas;
        option = {
            title: {
                text: '计划分布图',
                left: 'center'
            },
            tooltip: {
                trigger: 'item'
            },
            legend: {
                orient: 'vertical',
                left: 'left'
            },
            series: [
                {
                    type: 'pie',
                    data: datas
                }
            ]
        };
        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);
    });
}

doCount();
