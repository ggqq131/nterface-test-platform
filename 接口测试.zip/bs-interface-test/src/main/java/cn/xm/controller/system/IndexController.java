package cn.xm.controller.system;


import cn.xm.utils.HttpUtils;
import cn.xm.utils.JSONResultUtil;
import cn.xm.utils.system.MySystemUtils;
import cn.xm.vo.InterfaceRequestVO;
import cn.xm.vo.InterfaceResponseVO;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

@RequestMapping
@Controller
public class IndexController {

    @RequestMapping("/{path}")
    public String index(ModelMap map, HttpServletRequest request, @PathVariable(value = "path") String path) {
        request.setAttribute("productName", MySystemUtils.getProductName());
        return path;
    }

    @PostMapping("/doRequest")
    @ResponseBody
    public JSONResultUtil<InterfaceResponseVO> doRequest(@RequestBody @Validated InterfaceRequestVO interfaceRequest) {
        // 校验 参数
        check(interfaceRequest);

        String url = interfaceRequest.getUrl();
        String requestMethod = interfaceRequest.getRequestMethod();
        String formParam = interfaceRequest.getFormParam();
        String requestHeader = interfaceRequest.getRequestHeader();
        Map<String, String> convertedParam = convert(formParam);
        Map<String, String> convertedHeader = convert(requestHeader);

        InterfaceResponseVO interfaceResponseVO = HttpUtils.doRequest(url, requestMethod, convertedParam, convertedHeader, interfaceRequest.getJsonParam());
        return new JSONResultUtil<>(true, "true", interfaceResponseVO);
    }

    private Map<String, String> convert(String formParam) {
        if (StringUtils.isBlank(formParam)) {
            return new HashMap<>();
        }

        Map<String, String> result = new HashMap<>();
        String[] split = formParam.split("\n");
        for (String nameAndValue : split) {
            String[] split1 = nameAndValue.split("=");
            if (split1.length == 1) {
                result.put(split1[0], split1[0]);
            } else {
                result.put(split1[0], split1[1]);
            }
        }

        return result;
    }

    private void check(InterfaceRequestVO interfaceRequest) {
        if (HttpUtils.isGet(interfaceRequest.getRequestMethod()) || HttpUtils.isDelete(interfaceRequest.getRequestMethod())) {
            if (StringUtils.isNotBlank(interfaceRequest.getJsonParam())) {
                throw new IllegalStateException("get、delete 不能发送json 请求");
            }
        }
        if (StringUtils.isNotBlank(interfaceRequest.getJsonParam()) && StringUtils.isNotBlank(interfaceRequest.getFormParam())) {
            throw new IllegalStateException("json参数和表单参数不能同时有");
        }
    }
}
