package cn.xm.controller.system;

import cn.xm.utils.JSONResultUtil;
import cn.xm.vo.InterfaceRequestVO;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;

/**
 * @description
 */
@RequestMapping("/test")
@RestController
public class TestController {

    @GetMapping("/get/{id}")
    public JSONResultUtil<String> get(@PathVariable Integer id, @RequestParam String param1, @RequestParam String param2,
                                      HttpServletResponse response, @RequestHeader String header1) {
        System.out.println("cn.xm.controller.system.TestController.get");
        System.out.println(id);
        System.out.println(param1);
        System.out.println(param2);
        System.out.println(header1);
        response.setHeader("id", id.toString());
        response.setHeader("param1", param1);
        response.setHeader("param2", param2);
        return new JSONResultUtil<>(true, "ok", "get");
    }

    @PutMapping("/put")
    public JSONResultUtil<String> put(@RequestBody InterfaceRequestVO request, HttpServletResponse response) {
        System.out.println("cn.xm.controller.system.TestController.put");
        System.out.println(request);
        return new JSONResultUtil<>(true, "ok", "put");
    }

    @PostMapping("/post")
    public JSONResultUtil<String> post(@RequestBody InterfaceRequestVO request, @RequestParam String param2, HttpServletResponse response) {
        System.out.println("cn.xm.controller.system.TestController.post");
        System.out.println(request);
        System.out.println(param2);
        response.setHeader("param2", param2);
        return new JSONResultUtil<>(true, "ok", "post");
    }

    @DeleteMapping("/delete")
    public JSONResultUtil<String> delete(@RequestParam String param1, HttpServletResponse response) {
        System.out.println("cn.xm.controller.system.TestController.delete");
        System.out.println(param1);
        response.setHeader("param1", param1);
        return new JSONResultUtil<>(true, "ok", "delete");
    }
}
