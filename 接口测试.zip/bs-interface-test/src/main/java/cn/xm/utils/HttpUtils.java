package cn.xm.utils;


import cn.xm.vo.InterfaceResponseVO;
import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.Header;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.*;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.*;

/**
 * http工具类的使用
 *
 * @author Administrator
 */
public class HttpUtils {

    private static Logger logger = LoggerFactory.getLogger(HttpUtils.class);


    public static InterfaceResponseVO doRequest(String url, String requestMethod, Map<String, String> param, Map<String, String> requestHeaders, String jsonParam) {
        try {
            boolean isJsonRequest = StringUtils.isNotBlank(jsonParam);
            // 处理非json请求参数
            // ajax请求 get请求与delete 请求没有请求体， 所以参数需要在url 拼接。 put、post 写在请求体中
            if (!isJsonRequest) {
                if (isGet(requestMethod) || isDelete(requestMethod)) {
                    if (param != null && param.size() > 0) {
                        List<NameValuePair> nvps = new ArrayList<NameValuePair>();
                        for (Iterator<String> iter = param.keySet().iterator(); iter.hasNext(); ) {
                            String name = iter.next();
                            String value = param.get(name);
                            nvps.add(new BasicNameValuePair(name, value));
                        }
                        String paramsStr = EntityUtils.toString(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
                        if (url.contains("?")) {
                            url += "&" + paramsStr;
                        } else {
                            url += "?" + paramsStr;
                        }
                    }
                }
            }

            // 构造对象
            HttpRequestBase request = getRequest(url, requestMethod);
            if (MapUtils.isNotEmpty(requestHeaders)) {
                requestHeaders.forEach((k, v) -> {
                    request.setHeader(k, v);
                });
            }
            if (isJsonRequest) {
                request.setHeader("Accept", "application/json");
                request.setHeader("Content-Type", "application/json");
                StringEntity entity = new StringEntity(jsonParam, HTTP.UTF_8);
                HttpEntityEnclosingRequestBase requestBase = (HttpEntityEnclosingRequestBase) request;
                requestBase.setEntity(entity);
            }

            // 处理put、post 请求
            if (isPut(requestMethod) || isPost(requestMethod)) {
                HttpEntityEnclosingRequestBase requestBase = (HttpEntityEnclosingRequestBase) request;
                if (param != null && param.size() > 0) {
                    List<NameValuePair> nvps = new ArrayList<NameValuePair>();
                    for (Iterator<String> iter = param.keySet().iterator(); iter.hasNext(); ) {
                        String name = iter.next();
                        String value = param.get(name);
                        nvps.add(new BasicNameValuePair(name, value));
                    }
                    requestBase.setEntity(new UrlEncodedFormEntity(nvps, HTTP.UTF_8));
                }
            }


            CloseableHttpClient client = HttpClientBuilder.create().build();
            CloseableHttpResponse response = client.execute(request);
            /** 请求发送成功，并得到响应 **/
            InterfaceResponseVO interfaceResponseVO = new InterfaceResponseVO();
            if (response != null) {
                Header[] allHeaders = response.getAllHeaders();
                int statusCode = response.getStatusLine().getStatusCode();
                String responseStr = EntityUtils.toString(response.getEntity(), "utf-8");
                interfaceResponseVO.setCode(statusCode);
                interfaceResponseVO.setResponseStr(responseStr);
                if (ArrayUtils.isNotEmpty(allHeaders)) {
                    Map<String, String> stringStringHashMap = new HashMap<>();
                    interfaceResponseVO.setHeaders(stringStringHashMap);
                    for (Header header : allHeaders) {
                        stringStringHashMap.put(header.getName(), header.getValue());
                    }
                }
            }

            return interfaceResponseVO;
        } catch (Exception exception) {
            logger.error("execute error, url: {}", url, exception);
            InterfaceResponseVO interfaceResponseVO = new InterfaceResponseVO();
            interfaceResponseVO.setCode(500);
            interfaceResponseVO.setResponseStr("自身服务器发送数据错误: " + exception.getMessage());
            return interfaceResponseVO;
        }
    }

    private static HttpRequestBase getRequest(String url, String requestMethod) {
        if (isPut(requestMethod)) {
            return new HttpPut(url);
        }
        if (isDelete(requestMethod)) {
            return new HttpDelete(url);
        }
        if (isPost(requestMethod)) {
            return new HttpPost(url);
        }
        if (isGet(requestMethod)) {
            return new HttpGet(url);
        }
        return null;
    }

    public static final boolean isGet(String requestMethod) {
        return "get".equals(requestMethod);
    }

    public static final boolean isDelete(String requestMethod) {
        return "delete".equals(requestMethod);
    }

    public static final boolean isPut(String requestMethod) {
        return "put".equals(requestMethod);
    }

    public static final boolean isPost(String requestMethod) {
        return "post".equals(requestMethod);
    }

}