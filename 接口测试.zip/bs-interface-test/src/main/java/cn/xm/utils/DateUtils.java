package cn.xm.utils;

import java.util.Date;

public class DateUtils {

    /**
     * 计算两个日期差（毫秒）date1 - date2
     *
     * @param date1 时间1
     * @param date2 时间2
     * @return 相差秒数
     */
    public static long diffTwoDate(Date date1, Date date2) {
        long l1 = date1.getTime();
        long l2 = date2.getTime();
        return (l1 - l2) / 1000;
    }
}
