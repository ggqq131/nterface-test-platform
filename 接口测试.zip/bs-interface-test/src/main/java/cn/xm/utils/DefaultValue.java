package cn.xm.utils;


public class DefaultValue {

    /**
     * 每页数量
     */
    public static final int PAGE_SIZE = 6;


    /**
     * 消息类型
     */
    public static final String SYSTEM_SETTING_KEY_MESSAGE_TYPE = "messageType";

    /**
     * 任务类型
     */
    public static final String SYSTEM_SETTING_KEY_TASK_TYPE = "taskType";

    /**
     * 每页数量
     */
    public static final long MIN_TASK_TIME = 20 * 60;

    public static final String TASK_STATUS_NOT_START = "未开始";

    public static final String TASK_STATUS_RUNNING = "进行中";

    public static final String TASK_STATUS_FINISHED = "已结束";

}
