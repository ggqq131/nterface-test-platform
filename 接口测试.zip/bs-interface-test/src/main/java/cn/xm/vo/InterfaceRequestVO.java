package cn.xm.vo;

import javax.validation.constraints.NotNull;

/**
 * 接口请求参数
 */
public class InterfaceRequestVO {

    /**
     * 请求url
     */
    @NotNull(message = "请求url不能为空")
    private String url;

    /**
     * 请求方法
     */
    @NotNull(message = "请求url不能为空")
    private String requestMethod;

    /**
     * 请求头
     */
    private String requestHeader;

    /**
     * 表单参数
     */
    private String formParam;

    /**
     * json 参数
     */
    private String jsonParam;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getRequestMethod() {
        return requestMethod;
    }

    public void setRequestMethod(String requestMethod) {
        this.requestMethod = requestMethod;
    }

    public String getRequestHeader() {
        return requestHeader;
    }

    public void setRequestHeader(String requestHeader) {
        this.requestHeader = requestHeader;
    }

    public String getFormParam() {
        return formParam;
    }

    public void setFormParam(String formParam) {
        this.formParam = formParam;
    }

    public String getJsonParam() {
        return jsonParam;
    }

    public void setJsonParam(String jsonParam) {
        this.jsonParam = jsonParam;
    }

    @Override
    public String toString() {
        return "InterfaceRequestVO{" +
                "url='" + url + '\'' +
                ", requestMethod='" + requestMethod + '\'' +
                ", requestHeader='" + requestHeader + '\'' +
                ", formParam='" + formParam + '\'' +
                ", jsonParam='" + jsonParam + '\'' +
                '}';
    }
}
