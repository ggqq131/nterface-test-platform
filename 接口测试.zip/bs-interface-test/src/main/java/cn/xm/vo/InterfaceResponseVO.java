package cn.xm.vo;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 接口响应参数
 */
public class InterfaceResponseVO {

    /**
     * 请求url
     */
    private String responseStr;

    private int code;

    private Map<String, String> headers;

    public String getResponseStr() {
        return responseStr;
    }

    public void setResponseStr(String responseStr) {
        this.responseStr = responseStr;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public Map<String, String> getHeaders() {
        return headers;
    }

    public void setHeaders(Map<String, String> headers) {
        this.headers = headers;
    }

    public String getHeadersStr() {
        if (MapUtils.isEmpty(headers)) {
            return "";
        }
        List<String> allHeaders = new ArrayList<>();
        headers.forEach((k, v) -> {
            allHeaders.add(k + ": " + v);
        });
        return StringUtils.join(allHeaders, "\r\n");
    }
}
